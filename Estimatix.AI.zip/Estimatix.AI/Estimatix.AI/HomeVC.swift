//
//  HomeVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/17/20.
//

import UIKit
import Firebase
import CoreLocation

class HomeVC: BaseViewController {
    
    @IBOutlet weak var selectRoofingImagesBackgroundView: UIView!
    @IBOutlet weak var selectSidingImagesBackgroundView: UIView!
    @IBOutlet weak var selectFencingImagesBackgroundView: UIView!
    @IBOutlet weak var selectInteriorImagesBackgroundVIew: UIView!
    @IBOutlet weak var addAdminInfoBackgroundView: UIView!
    
    @IBOutlet weak var roofingLabel: UILabel!
    @IBOutlet weak var sidingLabel: UILabel!
    @IBOutlet weak var fencingLabel: UILabel!
    @IBOutlet weak var interiorLabel: UILabel!
    @IBOutlet weak var adminInfoLabel: UILabel!
    @IBOutlet weak var adminNameLabel: UILabel!
    @IBOutlet weak var adminAddressLabel: UILabel!
    @IBOutlet weak var adminEmailLabel: UILabel!
    @IBOutlet weak var adminPhoneLabel: UILabel!
    
    let storageRef = Storage.storage().reference()
    var ref: DatabaseReference!
    var locationManager: CLLocationManager?
    
    var uploading = [String: Bool]()
    var projectId = ""
    var childUpdates = [String: String]()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateLayout()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
        
        self.initNavigationBarItems(title: "Estimatix.AI")
        
        initiateLayout()
        loadProjectData()
        
        locationManager = CLLocationManager()
        locationManager!.delegate = self
        locationManager!.requestWhenInUseAuthorization()
    }
    
    private func setupNavigationBarItems() {
        let titleImageView = UIImageView(image: UIImage(named: "option_icon"))
        navigationItem.titleView = titleImageView
    }
    
    func initiateLayout() {
        selectRoofingImagesBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
        selectSidingImagesBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
        selectFencingImagesBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
        selectInteriorImagesBackgroundVIew.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
        addAdminInfoBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
    }
    
    func createNewProject(completion: @escaping ((Bool) -> Void)) {
        let name = UserDefaults.standard.string(forKey: Constants.firstName)! + " " + UserDefaults.standard.string(forKey: Constants.lastName)!
        projectId = ref.childByAutoId().key!
        ref.child("ProjectSubmissions").child(projectId).child("userInfo").setValue([
            "email": UserDefaults.standard.string(forKey: Constants.email),
            "name": name,
            "phone": UserDefaults.standard.string(forKey: Constants.phoneNumber),
            "uid": uuid
        ]) { error, project in
            if error == nil {
                completion(true)
            } else {
                completion(false)
            }
        }
    }
    
    private func uploadData(_ field: String, _ imageModels: [ImageModel], _ index: Int) {
        let data = UserDefaults.standard.data(forKey: "\(field)Image\(imageModels[index].id)")!
        let fieldRef = storageRef.child(uuid).child(projectId).child(field).child("\(field)image\(index)")
        fieldRef.putData(data, metadata: nil) { metadata, error in
            guard metadata != nil else {
                return
            }
            fieldRef.downloadURL { (url, error) in
                guard let downloadURL = url else {
                    // Uh-oh, an error occurred!
                    return
                }
                
                self.childUpdates["/ProjectSubmissions/\(self.projectId)/\(field)/\(field + imageModels[index].id)"] = downloadURL.absoluteString
                
                let next = index + 1
                if imageModels.count == next {
                    self.uploading[field] = false
                    self.trySubmit()
                } else {
                    self.uploadData(field, imageModels, next)
                }
            }
        }
    }
    
    func uploadFiles() {
        childUpdates = [String: String]()
        uploading = ["roofing": true, "siding": true, "fencing": true, "interior": true]
        
        if roofingImages.count > 0 {
            uploadData("roofing", roofingImages, 0)
        } else {
            uploading["roofing"] = false
        }
        
        if sidingImages.count > 0 {
            uploadData("siding", sidingImages, 0)
        } else {
            uploading["siding"] = false
        }
        
        if fencingImages.count > 0 {
            uploadData("fencing", fencingImages, 0)
        } else {
            uploading["fencing"] = false
        }
        
        if interiorImages.count > 0 {
            uploadData("interior", interiorImages, 0)
        } else {
            uploading["interior"] = false
        }
        
        trySubmit()
    }
    
    func trySubmit() {
        if !uploading["roofing"]! && !uploading["siding"]! && !uploading["fencing"]! && !uploading["interior"]! {
            submitProjectDetails()
        }
    }
    
    func submitProjectDetails() {
        let date = Date()
        let df = DateFormatter()
        df.dateFormat = "dd/MM/yyyy HH:mm:ss"
        let today = df.string(from: date)
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/address"] = myAdminInfo.address
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/email"] = myAdminInfo.email
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/fencetoRepaint"] = myAdminInfo.fencetoRepaint
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/fencetoReplace"] = myAdminInfo.fencetoReplace
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/latitude"] = myAdminInfo.latitude
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/longitude"] = myAdminInfo.longitude
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/name"] = myAdminInfo.name
        childUpdates["/ProjectSubmissions/\(projectId)/adminInfo/phone"] = myAdminInfo.phone
        childUpdates["/ProjectSubmissions/\(projectId)/userInfo/date"] = today
        self.ref.updateChildValues(childUpdates) { error, result in
            myAdminInfo = AdminInfoModel()
            roofingImages = [ImageModel]()
            sidingImages = [ImageModel]()
            fencingImages = [ImageModel]()
            interiorImages = [ImageModel]()
            SQLiterManager().dropTables()
            SQLiterManager().createTables()
            self.updateLayout()
            self.view.hideToastActivity()
        }
    }
    
    func loadProjectData() {
        self.view.makeToastActivity(.center)
        SQLiterManager().readImageTable(Constants.roofingImageTableName) { roofings in
            roofingImages = roofings
            SQLiterManager().readImageTable(Constants.sidingImageTableName) { sidings in
                sidingImages = sidings
                SQLiterManager().readImageTable(Constants.fencingImageTableName) { fencings in
                    fencingImages = fencings
                    SQLiterManager().readImageTable(Constants.interiorImageTableName) { initeriors in
                        interiorImages = initeriors
                        SQLiterManager().readAdminInfoTable { adminInfo in
                            myAdminInfo = adminInfo
                            self.updateLayout()
                            self.view.hideToastActivity()
                        }
                    }
                }
            }
        }
    }
    
    func updateLayout() {
        if roofingImages.count > 0 {
            roofingLabel.text = "Roofing: \(roofingImages.count) Images Selected"
            roofingLabel.textColor = .systemGreen
        } else {
            roofingLabel.text = "Roofing: 0 Images Selected"
            roofingLabel.textColor = .black
        }
        if sidingImages.count > 0 {
            sidingLabel.text = "Siding: \(sidingImages.count) Images Selected"
            sidingLabel.textColor = .systemGreen
        } else {
            sidingLabel.text = "Siding: 0 Images Selected"
            sidingLabel.textColor = .black
        }
        if fencingImages.count > 0 {
            fencingLabel.text = "Fencing: \(fencingImages.count) Images Selected"
            fencingLabel.textColor = .systemGreen
        } else {
            fencingLabel.text = "Fencing: 0 Images Selected"
            fencingLabel.textColor = .black
        }
        if interiorImages.count > 0 {
            interiorLabel.text = "Interior: \(interiorImages.count) Images Selected"
            interiorLabel.textColor = .systemGreen
        } else {
            interiorLabel.text = "Interior: 0 Images Selected"
            interiorLabel.textColor = .black
        }
        if myAdminInfo.name != "" {
            adminInfoLabel.textColor = .systemGreen
            adminNameLabel.text = "Admin Name: \(myAdminInfo.name)"
            adminAddressLabel.text = "Admin Address: \(myAdminInfo.address)"
            adminEmailLabel.text = "Admin Email: \(myAdminInfo.email)"
            adminPhoneLabel.text = "Admin Phone: \(myAdminInfo.phone)"
        } else {
            adminInfoLabel.textColor = .black
            adminNameLabel.text = ""
            adminAddressLabel.text = ""
            adminEmailLabel.text = ""
            adminPhoneLabel.text = ""
        }
    }
        
    @IBAction func selectRoofingImagesButtonTapped(_ sender: Any) {
        openVC(identifier: "SelectRoofingImagesVC")
    }
    
    @IBAction func selectSidingImagesButtonTapped(_ sender: Any) {
        openVC(identifier: "SelectSidingImagesVC")
    }
    
    @IBAction func selectFencingImagesButtonTapped(_ sender: Any) {
        openVC(identifier: "SelectFencingImagesVC")
    }
    
    @IBAction func selectInteriorImagesButtonTapped(_ sender: Any) {
        openVC(identifier: "SelectInteriorImagesVC")
    }
    
    @IBAction func addAdminInfoButtonTapped(_ sender: Any) {
        openVC(identifier: "AddAdminInfoVC")
    }
    
    @IBAction func submitButtonTapped(_ sender: Any) {
        if roofingImages.count == 0 && sidingImages.count == 0 && fencingImages.count == 0 && interiorImages.count == 0 {
            self.showAlertWithMessage(message: "Please select one of Roofing/Siding/Fencing/Interior images.")
            return
        }
        
        self.view.makeToastActivity(.center)
        
        createNewProject { (result) in
            if result {
                self.uploadFiles()
            } else {
                self.view.hideToastActivity()
                self.showAlertWithMessage(message: "There was an error to submit project. Please try again.")
            }
        }
    }
    
}

extension HomeVC: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.sorted(by: {$0.timestamp > $1.timestamp}).first {
            myAdminInfo.latitude = String(Float(location.coordinate.latitude))
            myAdminInfo.longitude = String(Float(location.coordinate.longitude))
        }
        manager.stopUpdatingLocation()
    }
}
