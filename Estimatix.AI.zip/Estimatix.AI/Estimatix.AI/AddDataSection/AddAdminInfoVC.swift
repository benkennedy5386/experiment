//
//  AddAdminInfoVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/20/20.
//

import UIKit
import MaterialComponents.MaterialTextControls_FilledTextFields

class AddAdminInfoVC: BaseViewController, UITextFieldDelegate {
    
    @IBOutlet weak var nameTextField: MDCFilledTextField!
    @IBOutlet weak var addressTextField: MDCFilledTextField!
    @IBOutlet weak var emailAddressTextField: MDCFilledTextField!
    @IBOutlet weak var phoneTextField: MDCFilledTextField!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initTextField()
        
        self.initNavigationBarItems(title: "Admin")
        
        nameTextField.text = myAdminInfo.name
        addressTextField.text = myAdminInfo.address
        emailAddressTextField.text = myAdminInfo.email
        phoneTextField.text = myAdminInfo.phone
    }
    
    private func initTextField() {
        nameTextField.delegate = self
        addressTextField.delegate = self
        emailAddressTextField.delegate = self
        phoneTextField.delegate = self
        
        nameTextField.setFloatingLabelColor(Constants.primaryColor, for: .editing)
        nameTextField.setUnderlineColor(Constants.primaryColor, for: .editing)
        nameTextField.tintColor = Constants.primaryColor
        
        addressTextField.setFloatingLabelColor(Constants.primaryColor, for: .editing)
        addressTextField.setUnderlineColor(Constants.primaryColor, for: .editing)
        addressTextField.tintColor = Constants.primaryColor
        
        emailAddressTextField.setFloatingLabelColor(Constants.primaryColor, for: .editing)
        emailAddressTextField.setUnderlineColor(Constants.primaryColor, for: .editing)
        emailAddressTextField.tintColor = Constants.primaryColor
        
        phoneTextField.setFloatingLabelColor(Constants.primaryColor, for: .editing)
        phoneTextField.setUnderlineColor(Constants.primaryColor, for: .editing)
        phoneTextField.tintColor = Constants.primaryColor
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == phoneTextField {
            self.view.endEditing(true)
        }
        if textField == emailAddressTextField {
            phoneTextField.becomeFirstResponder()
        }
        if textField == addressTextField {
            emailAddressTextField.becomeFirstResponder()
        }
        if textField == nameTextField {
            addressTextField.becomeFirstResponder()
        }
        return false
    }
    
    @IBAction func mainMenuButtonTapped(_ sender: Any) {
        openPreviousVC()
    }
    
    @IBAction func submitAdminInfoButtonTapped(_ sender: Any) {
        myAdminInfo.name = self.nameTextField.text!
        myAdminInfo.address = self.addressTextField.text!
        myAdminInfo.email = self.emailAddressTextField.text!
        myAdminInfo.phone = self.phoneTextField.text!
        SQLiterManager().updateAdminInfoTable(myAdminInfo)
        self.openPreviousVC()
    }
    
    private func validateForm() -> Bool {
        var formValid = true
        
        let name = nameTextField.text!
        if (name.isEmpty) {
            nameTextField.leadingAssistiveLabel.text = "Name is required."
            formValid = false
        } else {
            nameTextField.leadingAssistiveLabel.text = ""
        }
        
        let address = addressTextField.text!
        if (address.isEmpty) {
            addressTextField.leadingAssistiveLabel.text = "Address is required."
            formValid = false
        } else {
            addressTextField.leadingAssistiveLabel.text = ""
        }
        
        let email = emailAddressTextField.text!
        if (email.isEmpty) {
            emailAddressTextField.leadingAssistiveLabel.text = "Email Address is required."
            formValid = false
        } else if (!functions.isValidEmail(email)) {
            emailAddressTextField.leadingAssistiveLabel.text = "Enter a valid email address."
            formValid = false
        } else {
            emailAddressTextField.leadingAssistiveLabel.text = ""
        }
        
        let phone = phoneTextField.text!
        if (phone.isEmpty) {
            phoneTextField.leadingAssistiveLabel.text = "Phone is required."
            formValid = false
        } else {
            phoneTextField.leadingAssistiveLabel.text = ""
        }
        
        return formValid
    }
}
