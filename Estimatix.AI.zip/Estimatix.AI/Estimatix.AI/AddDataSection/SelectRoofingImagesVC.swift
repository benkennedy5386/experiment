//
//  SelectRoofingImagesVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/19/20.
//

import UIKit

class SelectRoofingImagesVC: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIDocumentPickerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var selectedImagesCollectionView: UICollectionView!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var titleLabel: UILabel!
    let cellReuseIdentifier = "RoofingImageViewCell"
    var selectedId = 0
    var testURLs = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initNavigationBarItems(title: "Roofing")
        selectedImagesCollectionView.reloadData()
        
        if roofingImages.count > 0 {
            titleLabel.text = "Selected Images"
            titleLabel.textColor = .systemGreen
            collectionViewHeight.constant = 200
        }
    }
    
    @IBAction func mainMenuButtonTapped(_ sender: Any) {
        openPreviousVC()
    }
    
    @IBAction func selectPhotoButtonTapped(_ sender: UIButton) {
        selectedId = sender.tag - 101
        if ImageModel().findImageModel(value: "\(selectedId)", in: roofingImages) != nil {
            return
        }
        showAlertWithOptions(message: "Please select option below.", positiveOption: "From Photo Album", negativeOption: "From Files", completion: { (result) in
            if result {
                self.selectPhoto()
            } else {
                self.selectFile()
            }
        })
    }
    
    private func selectFile() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.jpeg, .png], asCopy: true)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .fullScreen
        present(documentPicker, animated: true, completion: nil)
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let image = UIImage(contentsOfFile: urls.first!.relativePath)
        UserDefaults.standard.set(image?.jpegData(compressionQuality: 1.0), forKey: "roofingImage\(selectedId)")
        saveFileURL(urls.first!.relativePath)
    }
    
    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        controller.dismiss(animated: true)
    }
    
    private func selectPhoto() {
        let imagePicker = UIImagePickerController()
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.dismiss(animated: true, completion: nil)
        let url = info[.imageURL] as! URL
        let image = UIImage(contentsOfFile: url.relativePath)
        UserDefaults.standard.set(image?.jpegData(compressionQuality: 1.0), forKey: "roofingImage\(selectedId)")
        saveFileURL(url.relativePath)
    }
    
    private func saveFileURL(_ path: String) {
        let newImageModel = ImageModel(id: "\(self.selectedId)", url: path, name: "    Image \(self.selectedId + 1)")
        roofingImages.append(newImageModel)
        self.selectedImagesCollectionView.reloadData()
        self.titleLabel.text = "Selected Images"
        self.titleLabel.textColor = .systemGreen
        self.collectionViewHeight.constant = 200
        
        SQLiterManager().writeImageTable(Constants.roofingImageTableName, newImageModel)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return roofingImages.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellReuseIdentifier, for: indexPath)
            as! RoofingImageViewCell
        let roofingImage = roofingImages[indexPath.row]
        
        cell.set(roofingImage)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let roofImage = roofingImages[indexPath.row]
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let imageDetailVC = storyBoard.instantiateViewController(withIdentifier: "ImageDetailVC") as! ImageDetailVC
        imageDetailVC.modalPresentationStyle = .fullScreen
        imageDetailVC.selecteImageName = "roofingImage\(roofImage.id)"
        self.present(imageDetailVC, animated:false, completion:nil)
    }
}

class RoofingImageViewCell: UICollectionViewCell {
    
    @IBOutlet weak var selectedImageView: UIImageView!
    @IBOutlet weak var selectedImageLabel: UILabel!
    
    func set(_ selectedImage: ImageModel) {
        self.contentView.layer.cornerRadius = 25
        self.contentView.layer.masksToBounds = true;
        self.contentView.layer.borderWidth = 2;
        self.contentView.layer.borderColor = UIColor.systemGray6.cgColor
        
        let data = UserDefaults.standard.data(forKey: "roofingImage\(selectedImage.id)")!
        let image = UIImage(data: data)
        selectedImageView.image = image
        selectedImageLabel.text = selectedImage.name
    }
}
