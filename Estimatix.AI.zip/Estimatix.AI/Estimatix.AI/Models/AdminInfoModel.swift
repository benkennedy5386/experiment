//
//  AdminInfoModel.swift
//  Estimatix.AI
//
//  Created by yrm on 11/29/20.
//

import Foundation

class AdminInfoModel: Codable {
    var id: Int = 0
    var address: String = ""
    var email: String = ""
    var fencetoRepaint: String = ""
    var fencetoReplace: String = ""
    var latitude: String = ""
    var longitude: String = ""
    var name: String = ""
    var phone: String = ""
    
    init() { }

    convenience init(address: String, email: String, fencetoRepaint: String, fencetoReplace: String, latitude: String, longitude: String, name: String, phone: String) {
        self.init()
        self.address = address
        self.email = email
        self.fencetoRepaint = fencetoRepaint
        self.fencetoReplace = fencetoReplace
        self.latitude = latitude
        self.longitude = longitude
        self.name = name
        self.phone = phone
    }
}

var myAdminInfo = AdminInfoModel()
