//
//  SQLiteManager.swift
//  Estimatix.AI
//
//  Created by yrm on 12/1/20.
//

import Foundation
import SQLite

class SQLiterManager {
    
    let path = NSSearchPathForDirectoriesInDomains(
        .documentDirectory, .userDomainMask, true
    ).first!
    
//    func deleteDatabaseFile() {
//        let fileManager = FileManager.default
//        do {
//            let filePaths = try fileManager.contentsOfDirectory(atPath: "\(path)/estimatix_ai.sqlite3")
//            for filePath in filePaths {
//                try fileManager.removeItem(atPath: NSTemporaryDirectory() + filePath)
//            }
//        } catch {
//            print("SQLite delete database file failed: \(error)")
//        }
//    }
    
    func dropTables() {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let roofingImageTable = Table(Constants.roofingImageTableName)
            try db.run(roofingImageTable.drop())
            
            let sidingImageTable = Table(Constants.sidingImageTableName)
            try db.run(sidingImageTable.drop())
            
            let fencingImageTable = Table(Constants.fencingImageTableName)
            try db.run(fencingImageTable.drop())
            
            let interiorImageTable = Table(Constants.interiorImageTableName)
            try db.run(interiorImageTable.drop())
            
            let adminInfoTable = Table(Constants.adminInfoTableName)
            try db.run(adminInfoTable.drop())
            
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite drop table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func createImageTable(tableName: String) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let id = Expression<String>("id")
            let url = Expression<String>("url")
            let name = Expression<String>("name")
            
            let table = Table(tableName)
            
            try db.run(table.create { t in
                t.column(id, primaryKey: true)
                t.column(url)
                t.column(name)
            })
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite create image table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func createAdminInfoTable() {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let id = Expression<Int>("id")
            let address = Expression<String>("address")
            let email = Expression<String>("email")
            let fencetoRepaint = Expression<String>("fencetoRepaint")
            let fencetoReplace = Expression<String>("fencetoReplace")
            let latitude = Expression<String>("latitude")
            let longitude = Expression<String>("longitude")
            let name = Expression<String>("name")
            let phone = Expression<String>("phone")
            
            let table = Table(Constants.adminInfoTableName)
            
            try db.run(table.create { t in
                t.column(id, primaryKey: true)
                t.column(address)
                t.column(email)
                t.column(fencetoRepaint)
                t.column(fencetoReplace)
                t.column(latitude)
                t.column(longitude)
                t.column(name)
                t.column(phone)
            })
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite create admin_info table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func writeImageTable(_ tableName: String, _ imageModel: ImageModel) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let table = Table(tableName)
            try db.run(table.insert(imageModel))
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite write image table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func writeAdminInfoTable(_ adminInfoModel: AdminInfoModel) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let table = Table(Constants.adminInfoTableName)
            try db.run(table.insert(adminInfoModel))
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite write admin info table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func updateAdminInfoTable(_ adminInfoModel: AdminInfoModel) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            
            let table = Table(Constants.adminInfoTableName)
            let id = Expression<Int>("id")
            try db.run(table.filter(id == 0).update(adminInfoModel))
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite update admin info table failed: \(message), in \(statement)")
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func readImageTable(_ tableName: String, completion: @escaping (([ImageModel]) -> Void)) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            let table = Table(tableName)
            
            let images: [ImageModel] = try db.prepare(table).map { row in
                return try row.decode()
            }
            completion(images)
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite read image table failed: \(message), in \(statement)")
            completion([ImageModel]())
        } catch let error {
            print(error.localizedDescription)
            completion([ImageModel]())
        }
    }
    
    func readAdminInfoTable(completion: @escaping ((AdminInfoModel) -> Void)) {
        do {
            let db = try Connection("\(path)/estimatix_ai.sqlite3")
            let table = Table(Constants.adminInfoTableName)
            
            let models: [AdminInfoModel] = try db.prepare(table).map { row in
                return try row.decode()
            }
            completion(models[0])
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("SQLite read image table failed: \(message), in \(statement)")
            completion(AdminInfoModel())
        } catch let error {
            print(error.localizedDescription)
            completion(AdminInfoModel())
        }
    }
    
    func createTables() {
        SQLiterManager().createImageTable(tableName: Constants.roofingImageTableName)
        SQLiterManager().createImageTable(tableName: Constants.sidingImageTableName)
        SQLiterManager().createImageTable(tableName: Constants.fencingImageTableName)
        SQLiterManager().createImageTable(tableName: Constants.interiorImageTableName)
        SQLiterManager().createAdminInfoTable()
        SQLiterManager().writeAdminInfoTable(AdminInfoModel())
    }
}
