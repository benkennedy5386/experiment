//
//  Functions.swift
//  Estimatix.AI
//
//  Created by yrm on 11/17/20.
//

import Foundation
import UIKit
//import UserNotifications

class Functions {
            
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func updateToken() {
//        let token = sharedPreference.string(forKey: "fcmToken")!
//        var query: PFQuery<PFObject>!
//        if sharedPreference.string(forKey: Constants.role) == Constants.officeManager {
//            query = PFQuery(className:"oms")
//        } else {
//            query = PFQuery(className:"fpms")
//        }
//        query.getObjectInBackground(withId: sharedPreference.string(forKey: Constants.userID)!) { (user, error) in
//            if error != nil {
//                print("\(error?.localizedDescription ?? "no error message")")
//            } else {
//                user!["fcmToken"] = token
//                user!.saveInBackground { (result, error) in
//                    if error == nil {
//                        print("Batch write succeeded.")
//                    } else {
//                        print("Error writing batch \(error?.localizedDescription ?? "no error message")")
//                    }
//                }
//            }
//        }
    }
}

var functions = Functions()
