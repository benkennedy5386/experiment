//
//  Constants.swift
//  Estimatix.AI
//
//  Created by yrm on 11/17/20.
//

import Foundation
import UIKit

struct Constants {

    static let userID = "user_id"
    static let loggedIn = "logged_in"
    static let fcmToken = "fcmToken"
    static let email = "email"
    static let phoneNumber = "phoneNumber"
    static let firstName = "firstName"
    static let lastName = "lastName"
    static let projectId = "projectId"
    static let authVerificationID = "authVerificationID"
    
    static let roofingImageTableName = "roofing_images"
    static let sidingImageTableName = "siding_images"
    static let fencingImageTableName = "fencing_images"
    static let interiorImageTableName = "interior_images"
    static let adminInfoTableName = "admin_info"
    
    static let primaryColor = UIColor(red: 29.0/255.0, green: 142.0/255.0, blue: 189.0/250.0, alpha: 1.0)
    
    enum LoginType {
        case Google
        case PhoneNumber
    }
}
