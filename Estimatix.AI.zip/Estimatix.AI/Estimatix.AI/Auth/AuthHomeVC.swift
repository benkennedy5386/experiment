//
//  AuthHomeVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/17/20.
//

import UIKit
import Firebase
import FirebaseAuth
import GoogleSignIn

class AuthHomeVC: BaseViewController, GIDSignInDelegate {
    
    @IBOutlet weak var signInWithGoogleButtonBackgroundView: UIView!
    @IBOutlet weak var signInWithPhoneButtonBackgroundView: UIView!
    
    var ref: DatabaseReference!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        let firebaseAuth = Auth.auth()
        if firebaseAuth.currentUser != nil {
            uuid = firebaseAuth.currentUser!.uid
            openVC(identifier: "HomeVC")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
        
        NotificationCenter.default.addObserver(self, selector: #selector(sendVerificationCode), name: Notification.Name("sendVerificationCode"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(signInWithVerificationCode), name: Notification.Name("signInWithVerificationCode"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(createNewUser), name: Notification.Name("createNewUser"), object: nil)

        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance().delegate=self
        GIDSignIn.sharedInstance()?.presentingViewController = self
       
        initiateLayout()
    }
    
    func initiateLayout() {
        signInWithGoogleButtonBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
        signInWithPhoneButtonBackgroundView.setShadow(radius: 10, color: UIColor.systemGray.cgColor, opacity: 0.4, offset: CGSize(width: 0.5, height: 4.0))
    }
    
    func checkUserExist(completion: @escaping (Bool) -> Void) {
        ref.child("Users").child(uuid).observeSingleEvent(of: .value) { snapshot in
            let value = snapshot.value as? NSDictionary
            if value != nil {
                completion(true)
            } else {
                completion(false)
            }
        } withCancel: { error in
            completion(false)
        }
    }
    
    @objc func createNewUser() {
        ref.child("Users").child(uuid).setValue([
            "firstname": UserDefaults.standard.string(forKey: Constants.firstName),
            "lastname": UserDefaults.standard.string(forKey: Constants.lastName),
            "phonenumber": UserDefaults.standard.string(forKey: Constants.phoneNumber),
            "email": UserDefaults.standard.string(forKey: Constants.email)
        ]) { error, user in
            if error != nil {
                print(error?.localizedDescription)
            } else {
                self.openVC(identifier: "HomeVC")
            }
        }
    }
    
    @IBAction func signInWithGoogleButtonTapped(_ sender: Any) {
        GIDSignIn.sharedInstance().signIn()
    }
    
    @IBAction func signInWithPhoneButtonTapped(_ sender: Any) {
        openVC(identifier: "PhoneNumberVerificationVC")
    }
    
    @objc func sendVerificationCode(_ notification: NSNotification) {
        if let dict = notification.userInfo as NSDictionary? {
            if let phoneNumber = dict["phoneNumber"] as? String{
                PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { (verificationID, error) in
                    if let error = error {
                        print("\(error.localizedDescription)")
                    }

                    UserDefaults.standard.set(phoneNumber, forKey: Constants.email)
                    UserDefaults.standard.set(verificationID, forKey: Constants.authVerificationID)
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "showVerificationCodeInputView"), object: nil)
                }
            }
        }
    }
    
    @objc func signInWithVerificationCode(_ notification: NSNotification) {
        if let dict = notification.userInfo as NSDictionary? {
            if let verificationCode = dict["verificationCode"] as? String{
                let verificationID = UserDefaults.standard.string(forKey: Constants.authVerificationID)
                let credential = PhoneAuthProvider.provider().credential(withVerificationID: verificationID!, verificationCode: verificationCode)
                signInFirebaseWithCredential(credential, .PhoneNumber)
            }
        }
    }
    
}

extension AuthHomeVC {
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {

        if let error = error {
            print("\(error.localizedDescription)")
            return
        }
        
        UserDefaults.standard.set(user.profile.givenName, forKey: Constants.firstName)
        UserDefaults.standard.set(user.profile.familyName, forKey: Constants.lastName)
        UserDefaults.standard.set(user.profile.email, forKey: Constants.email)
        
        guard let authentication = user.authentication else { return }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken)
        signInFirebaseWithCredential(credential, .Google)
    }

    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        print("Google Signed Out")
    }
    
    func signInFirebaseWithCredential(_ credential: AuthCredential, _ type: Constants.LoginType) {
        Auth.auth().signIn(with: credential) { (authResult, error) in
            if let error = error {
                print("\(error.localizedDescription)")
                return
            }
            
            uuid = (authResult?.user.uid)!
            
            self.checkUserExist() { isExist in
                if isExist {
                    self.openVC(identifier: "HomeVC")
                } else {
                    switch type {
                    case .Google:
                        self.createNewUser()
                        break
                    case .PhoneNumber:
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "showUserDetailInputView"), object: nil)
                        break
                    }
                }
            }
        }
    }
    
}
