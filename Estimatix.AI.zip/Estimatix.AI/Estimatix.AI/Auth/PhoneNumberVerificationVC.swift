//
//  PhoneNumberVerificationVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/26/20.
//

import UIKit
import PhoneNumberKit
import PinCodeTextField
import MaterialComponents.MaterialTextControls_FilledTextFields

class PhoneNumberVerificationVC: BaseViewController {
    
    @IBOutlet weak var phoneNumberTextField: PhoneNumberTextField!
    @IBOutlet weak var phoneNumberInputView: UIView!
    @IBOutlet weak var verificationCodeInputView: UIView!
    @IBOutlet weak var userDetailInputView: UIView!
    @IBOutlet weak var pinCodeTextField: PinCodeTextField!
    @IBOutlet weak var firstNameTextField: MDCFilledTextField!
    @IBOutlet weak var lastNameTextField: MDCFilledTextField!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    let phoneNumberKit = PhoneNumberKit()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(showVerificationCodeInputView), name: Notification.Name("showVerificationCodeInputView"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showUserDetailInputView), name: Notification.Name("showUserDetailInputView"), object: nil)
        
        phoneNumberTextField.withFlag = true
        phoneNumberTextField.withPrefix = true
        phoneNumberTextField.withExamplePlaceholder = true
        
        phoneNumberInputView.isHidden = false
        verificationCodeInputView.isHidden = true
        userDetailInputView.isHidden = true
        
        pinCodeTextField.delegate = self
    }
    
    @objc func showVerificationCodeInputView() {
        phoneNumberInputView.isHidden = true
        verificationCodeInputView.isHidden = false
        userDetailInputView.isHidden = true
    }
    
    @objc func showUserDetailInputView() {
        phoneNumberInputView.isHidden = true
        verificationCodeInputView.isHidden = true
        userDetailInputView.isHidden = false
        phoneNumberLabel.text = UserDefaults.standard.string(forKey: Constants.phoneNumber)
    }
    
    @IBAction func verifyPhoneNumberButtonTapped(_ sender: Any) {
        if phoneNumberTextField.phoneNumber != nil {
            let phoneNumber = phoneNumberKit.format(phoneNumberTextField.phoneNumber!, toType: .e164)

            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "sendVerificationCode"), object: nil, userInfo: ["phoneNumber": phoneNumber])
        } else {
            print("Wrong Phone Number")
        }
    }
    
    @IBAction func continueButtonTapped(_ sender: Any) {
        if validateForm() {
            UserDefaults.standard.set(firstNameTextField.text, forKey: Constants.firstName)
            UserDefaults.standard.set(lastNameTextField.text, forKey: Constants.lastName)
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "createNewUser"), object: nil)
        }
    }
    
    private func validateForm() -> Bool {
        var formValid = true
        
        let firstname = firstNameTextField.text!
        if (firstname.isEmpty) {
            firstNameTextField.leadingAssistiveLabel.text = "First Name is required."
            formValid = false
        } else {
            firstNameTextField.leadingAssistiveLabel.text = ""
        }
        
        let lastname = lastNameTextField.text!
        if (lastname.isEmpty) {
            lastNameTextField.leadingAssistiveLabel.text = "Last Name is required."
            formValid = false
        } else {
            lastNameTextField.leadingAssistiveLabel.text = ""
        }
        
        return formValid
    }
}

extension PhoneNumberVerificationVC: PinCodeTextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: PinCodeTextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: PinCodeTextField) {
        
    }
    
    func textFieldValueChanged(_ textField: PinCodeTextField) {
        let verificationCode = textField.text ?? ""
        if verificationCode.count == 6 {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "signInWithVerificationCode"), object: nil, userInfo: ["verificationCode": pinCodeTextField.text!])
        }
    }
    
    func textFieldShouldEndEditing(_ textField: PinCodeTextField) -> Bool {
        return true
    }
    
    func textFieldShouldReturn(_ textField: PinCodeTextField) -> Bool {
        return true
    }
}
