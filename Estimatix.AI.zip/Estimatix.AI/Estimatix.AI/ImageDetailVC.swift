//
//  ImageDetailVC.swift
//  Estimatix.AI
//
//  Created by yrm on 11/29/20.
//

import UIKit
import ZoomImageView

class ImageDetailVC: BaseViewController {
    
    @IBOutlet weak var imageView: ZoomImageView!
    
    var selecteImageName: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let data = UserDefaults.standard.data(forKey: selecteImageName!)!
        let image = UIImage(data: data)
        
        self.imageView.zoomMode = .fill
        self.imageView.image = image
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
