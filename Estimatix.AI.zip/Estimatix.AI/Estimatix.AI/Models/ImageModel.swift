//
//  ImageModel.swift
//  Estimatix.AI
//
//  Created by yrm on 11/27/20.
//

import Foundation

class ImageModel: Codable {
    var id: String = ""
    var url: String = ""
    var name: String = ""
    
    init() { }
    
    convenience init(id: String, url: String, name: String) {
        self.init()
        self.id = id
        self.url = url
        self.name = name
    }
}

extension ImageModel {
    
    func findImageModel(value searchValue: String, in array: [ImageModel]) -> Int? {
        for (index, value) in array.enumerated()
        {
            if value.id == searchValue {
                return index
            }
        }
        return nil
    }
}

var roofingImages = [ImageModel]()
var sidingImages = [ImageModel]()
var fencingImages = [ImageModel]()
var interiorImages = [ImageModel]()
