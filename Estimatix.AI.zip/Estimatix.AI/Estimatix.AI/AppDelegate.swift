//
//  AppDelegate.swift
//  Estimatix.AI
//
//  Created by yrm on 11/16/20.
//

import UIKit
import Firebase
import FirebaseAuth

var uuid = ""

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        FirebaseApp.configure()
        
        if !UserDefaults.standard.bool(forKey: "appFirstTimeOpend") {
            UserDefaults.standard.setValue(true, forKey: "appFirstTimeOpend")
            do {
                try Auth.auth().signOut()
                
                SQLiterManager().dropTables()
                SQLiterManager().createTables()
            } catch { }
        }
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
        
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
    }
}
