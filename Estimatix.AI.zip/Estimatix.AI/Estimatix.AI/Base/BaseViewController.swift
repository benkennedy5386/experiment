//
//  BaseViewController.swift
//  Estimatix.AI
//
//  Created by yrm on 11/16/20.
//

import UIKit
import Toast_Swift
import DropDown
import FirebaseAuth

class BaseViewController: UIViewController {

    let progressView = UIProgressView(progressViewStyle: .default)
    let progressBackgroundView = UIView()
    let progressLabel = UILabel()
    let rightBarDropDown = DropDown()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func initNavigationBarItems(title: String) {
        navigationItem.hidesBackButton = true

        let titleButton = UIButton(type: .system)
        titleButton.setTitle(title, for: .normal)
        titleButton.setTitleColor(.white, for: .normal)
        titleButton.titleLabel?.font = .boldSystemFont(ofSize: 20)
        titleButton.isEnabled = false
        titleButton.isUserInteractionEnabled = false
        titleButton.frame = CGRect(x: 0, y: 0, width: 100, height: 34)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: titleButton)
        
        let optionButton = UIButton(type: .system)
        optionButton.setImage(UIImage(named: "option_icon"), for: .normal)
        optionButton.tintColor = .white
        optionButton.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        optionButton.addTarget(self, action: #selector(self.optionButtonTapped), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: optionButton)
        
        initDropDown()
    }

    private func initDropDown() {
        rightBarDropDown.anchorView = navigationItem.rightBarButtonItem
        rightBarDropDown.backgroundColor = .white
        rightBarDropDown.textFont = .systemFont(ofSize: 17)
        rightBarDropDown.dataSource = ["Settings", "Sign Out"]
    }
    
    @objc func optionButtonTapped() {
        rightBarDropDown.selectionAction = { (index: Int, item: String) in
            switch index {
            case 1:
                self.signOut()
            default:
                print("Selected item: \(item) at index: \(index)")
            }
        }
        rightBarDropDown.width = 150
        rightBarDropDown.bottomOffset = CGPoint(x: 0, y:(rightBarDropDown.anchorView?.plainView.bounds.height)!)
        rightBarDropDown.show()
    }
    
    func initProgressView() {
        progressView.tintColor = Constants.primaryColor
        progressView.trackTintColor = .lightGray
        progressView.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.width * 2 / 3, height: 10.0);
        progressView.progress = 0.0
        
        progressLabel.text = "0.0 %"
        progressLabel.textColor = Constants.primaryColor
        progressLabel.textAlignment = .center
        progressLabel.frame = CGRect(x: 0.0, y: 0.0, width: 100.0, height: 30.0)
        
        progressBackgroundView.addSubview(progressView)
        progressBackgroundView.addSubview(progressLabel)
        
        progressBackgroundView.tag = 100
        progressBackgroundView.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.width, height: self.view.frame.height);
        
        progressBackgroundView.center = self.view.center
        progressView.center = progressBackgroundView.center
        progressLabel.center.x = progressView.center.x
        progressLabel.center.y = progressView.center.y - 50
        
        progressBackgroundView.backgroundColor = .black
        progressBackgroundView.alpha = 0.5
    }
    
    func removeStackVC() {
        guard let navigationController = self.navigationController else { return }
        var navigationArray = navigationController.viewControllers
        navigationArray.remove(at: navigationArray.count - 2)
        self.navigationController?.viewControllers = navigationArray
    }
    
    func openPreviousVC() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func openVC(identifier: String) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let newVC = storyBoard.instantiateViewController(withIdentifier: identifier)
        self.navigationController?.pushViewController(newVC, animated: true)
    }
    
    func showAlertWithMessage(message: String) {
        let alert = UIAlertController(title: "Estimatix.AI", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: false, completion: nil)
        }))
        present(alert, animated: true, completion: nil)
    }
        
    func showAlertWithAction(message: String, completion: @escaping (Bool) -> ()) {
        let alert = UIAlertController(title: "Estimatix.AI", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: false, completion: nil)
            completion(true)
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
            completion(false)
        }))
        present(alert, animated: true, completion: nil)
    }
    
    func showAlertWithoutOption(message: String, completion: @escaping (Bool) -> ()) {
        let alert = UIAlertController(title: "Estimatix.AI", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: false, completion: nil)
            completion(true)
        }))
        present(alert, animated: true, completion: nil)
    }
    
    func showAlertWithOptions(message: String, positiveOption: String, negativeOption: String, completion: @escaping (Bool) -> ()) {
        let alert = UIAlertController(title: "Estimatix.AI", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: positiveOption, style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: false, completion: nil)
            completion(true)
        }))
        alert.addAction(UIAlertAction(title: negativeOption, style: .default, handler: { (action: UIAlertAction!) in
            completion(false)
        }))
        present(alert, animated: true, completion: nil)
    }

    func showProgressView() {
        self.view.addSubview(progressBackgroundView)
    }
    
    func hideProgressView() {
        self.view.viewWithTag(100)?.removeFromSuperview()
        progressView.setProgress(0.0, animated: false)
        progressLabel.text = "0.0 %"
    }
    
    func setProgress(_ progress: Progress) {
        progressView.setProgress(Float(progress.fractionCompleted), animated: true)
        progressLabel.text = "\(Int(progress.fractionCompleted * 100)) %"
    }
 
    func signOut() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            SQLiterManager().dropTables()
            SQLiterManager().createTables()
            openVC(identifier: "AuthHomeVC")
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
}
